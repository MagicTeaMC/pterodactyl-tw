# pterodactyl-tw  
❗在初期測試階段中，建議不要在正式環境中使用❗
## 關於
pterodactyl panel的繁體中文翻譯版本，修改自[原版](https://github.com/pterodactyl/panel)`v1.11.2`及部分文件修改自[中國版](https://github.com/pterodactyl-china/panel)`v1.11.2.0`。  
目前此翻譯版本存在許多不確定性，建議不要在實際環境中使用。  
我們也歡迎您使用pull request來協助我們翻譯、改進！
## 安裝及使用教學
我們目前有一個基礎的[安裝文檔](https://github.com/MagicTeaMC/pterodactyl-tw/blob/main/install.md)
未來我們會製作更完整的文檔，目前有任何問題可以前往[我的Discord伺服器](https://discord.gg/uQ4UXANnP2)詢問
## 版權
Pterodactyl® Copyright © 2015 - 2022 Dane Everitt and contributors.
Code released under the MIT License.
此翻譯版本也同樣遵照Pterodactyl開源憑證及MIT開源憑證